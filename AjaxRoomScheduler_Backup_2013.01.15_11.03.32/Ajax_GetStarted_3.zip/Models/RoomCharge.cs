namespace AjaxRoomScheduler.Models
{
    public class RoomCharge
    {
        public int RoomChargeId { get; set; }

        public string Description { get; set; }

        public decimal Value { get; set; }
    }

}